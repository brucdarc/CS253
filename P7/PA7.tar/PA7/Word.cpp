#include <Word.h>
#include <iostream>
using std::endl;
using std::cout;


StringTest Word::ST = StringTest();

void Word::setTI( double n )
{ TFIDF = n;}






















